//construct aws objects
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

/*
* lambda handler
* callsback an array of tutors on success
*/
exports.handler = async (event,context,callback) => {
    var response = await getTutors().then(result=>{
        return generateSchedule(result);
    });
    callback(null,response);
};

/*
* Scans the DB tutor table for tutors
*/
function getTutors() {
  var options = {TableName : process.env.TutorsTable};
  return new Promise(function(resolve,reject) {
    dynamo.scan(options, function(err,data){
      if (err) {
        reject(err);
      } else {
        //console.log("Scan results" + data);
        resolve(data.Items);
      }
    });
  }).then(function(result) {
      return(result);
    }, function(err) {
      return(err);
    });
}

/*
* Builds an initial schedule by creating an array of days filled with each day of week.
* Then assigns an array of timeblocks to each class and then adds the array of classes to each day.
* Returns JSON Object
*/
function generatePreSchedule() {
    var courses = ['1501','1505','1507','1510','1511','1513','1552','1564','1570','1571','1580','1585','1586','2623','2651','2601','2625','3717'];
    //var courses = ['1552','1585'];
    //var timeBlocks = []; //{"timeBlockId" : 1,"tutor":null}
    //for(let i = 1; i<13; i++) timeBlocks.push({"timeBlockId" : i,"tutor":null});
    var weekSkeleton = { days : [{
            "dayOfWeek" : "Monday",
            "courses" : []
        },{
            "dayOfWeek" : "Tuesday",
            "courses" : []
        },{
            "dayOfWeek" : "Wednesday",
            "courses" : []
        },{
            "dayOfWeek" : "Thursday",
            "courses" : []
        },{
            "dayOfWeek" : "Friday",
            "courses" : []
        }]
    };
    weekSkeleton.days.forEach((day)=>{
        courses.forEach((cl)=>{
            var timeBlocks = []; //{"timeBlockId" : 1,"tutor":null}
            for(let i = 1; i<13; i++) timeBlocks.push({"timeBlockId" : i,"tutor":null});
            day.courses.push({"cName" : cl, "timeBlocks" : timeBlocks.slice()});
        });
    });
    return weekSkeleton;
}

/*
* Retruns an array of tutors who are availble for a given class on a given day
* @params cName the name of the course to check for tutors
* @params Tutors an array of all available tutors
* @params dayOfWeek The day of the week to look for tutors
* @Returns array
*/
function getClassTutors(cName,Tutors,dayOfWeek) {
    var tempTutors = Tutors.filter(tutor=>{ //filter the tuors array for the desired subset
        return (tutor.preferredClasses.values.indexOf(cName) != -1 && tutor.availability.hasOwnProperty(dayOfWeek) && tutor.availability[dayOfWeek].values.length > 0);
    });
    var returnArray = [];
    tempTutors.forEach(tutor=>{
        //console.log(tutor);
        var tempTutor = {
            "tutorName" : tutor.tutorName,
            "availability" : {
                "Monday": { wrapperName: 'Set', values: [], type: 'Number' },
                "Tuesday": { wrapperName: 'Set', values: [], type: 'Number' },
                "Wednesday": { wrapperName: 'Set', values: [], type: 'Number' },
                "Thursday": { wrapperName: 'Set', values: [], type: 'Number' },
                "Friday": { wrapperName: 'Set', values: [], type: 'Number' }
            },
            "preferredClasses" : tutor.preferredClasses
        }
        if (tutor.availability.hasOwnProperty("Monday")) {tempTutor.availability["Monday"].values = tutor.availability["Monday"].values.slice();}
        if (tutor.availability.hasOwnProperty("Tuesday")) {tempTutor.availability["Tuesday"].values = tutor.availability["Tuesday"].values.slice();}
        if (tutor.availability.hasOwnProperty("Wednesday")) {tempTutor.availability["Wednesday"].values = tutor.availability["Wednesday"].values.slice();}
        if (tutor.availability.hasOwnProperty("Thursday")) {tempTutor.availability["Thursday"].values = tutor.availability["Thursday"].values.slice();}
        if (tutor.availability.hasOwnProperty("Friday")) {tempTutor.availability["Friday"].values = tutor.availability["Friday"].values.slice();}
        returnArray.push(tempTutor);
        //console.log(tempTutor.tutorName===tutor.tutorName);
    });
    return returnArray;
}

/*
* Generates the suggested schedule
* @params Tutors the array of all available tutors
* @Returns JSON Object
*/
function generateSchedule(Tutors) {
    Tutors = Tutors.filter(tutor=>{return tutor.availability != "None"});   //remove tutors with no availability
    //console.log(Tutors)
    console.log("Getting skeleton");
    var schedule = generatePreSchedule();                                   //init schedule
    
    schedule.days.forEach((day)=>{      //loop over days to schdule each day
        //console.log(day.dayOfWeek)
        day.courses.forEach((cl)=>{     //loop over classes in the day to schedule each class
            //console.log(cl.cName)
            var cTutors = getClassTutors(cl.cName,Tutors,day.dayOfWeek);    //get the tutors who can teach the class and are available for the day and store in temp array
            //cTutors.forEach(tutor=>{tutor.availability[day.dayOfWeek].values = tutor.availability[day.dayOfWeek].values.slice()})
            //cTutors.forEach(tutor=>{console.log(tutor.tutorName); console.log(tutor.availability)});
            //console.log(cl.cName + " day: " + day.dayOfWeek);
            //console.log(cTutors)
            var loopCheck = false;
            while(!loopCheck) {         //loop until class is fully scheduled or no more tutors are available
                if (cTutors.length == 0) loopCheck = true;  //if no tutors are available set loop to break
                for(let i = 0; i < cTutors.length; i++) {
                    if (!loopCheck) {
                        //console.log(cl)
                        loopCheck = scheduleTimeBlock(day,cl,cTutors[i],Tutors);    //schedule the class
                    } else scheduleTimeBlock(day,cl,cTutors[i],Tutors);
                }
            }
        });
    });
    return schedule;
}

/*
* schedules a tutor to tutor a class at the first available timeblock
* @return boolean
*/
function scheduleTimeBlock(day,cl,tutor,Tutors) {
    //console.log(tutor.tutorName)
    //console.log(tutor.availability[day.dayOfWeek].values[0])
    //console.log("ClTB: " + cl.timeBlocks[(tutor.availability[day.dayOfWeek].values[0])-1])
    console.log(tutor.availability[day.dayOfWeek].values.length > 0 && cl.timeBlocks[(tutor.availability[day.dayOfWeek].values[0])-1].tutor == null)
    if (tutor.availability[day.dayOfWeek].values.length > 0 && cl.timeBlocks[(tutor.availability[day.dayOfWeek].values[0])-1].tutor == null) {             //check if the first time the tutor is available has been scheduled for this class
        cl.timeBlocks[(tutor.availability[day.dayOfWeek].values[0])-1].tutor = tutor.tutorName;     //set this tutor as the tutor for the time for this class
        var breakVar = 1;
        for (let i = 0; i < tutor.preferredClasses.values.length; i++) {                            //attempt to schedule tutor to cover two additional classes at the same time
            let tCl = tutor.preferredClasses.values[i];                                             //get the class the tutor can teach
            //console.log(tutor.tutorName + " " + tCl);
            let clTB = day.courses.find(course=>{return course.cName==tCl}).timeBlocks[(tutor.availability[day.dayOfWeek].values[0])-1];    //get the timeblock for the class
            //console.log(clTB.tutor)
            if (clTB.tutor == null) {                       //check if the first time the tutor is available has been scheduled for this class
                //console.log("here")
                clTB.tutor = tutor.tutorName;               //set tutor as the tutor for the class for the time
                breakVar++;
            }
            if (breakVar == 3) {break}                     //if tutor has been scheduled for 2 additional classes break
        }
        //console.log(tutor.availability)
        console.log(tutor.availability[day.dayOfWeek].values)
        tutor.availability[day.dayOfWeek].values.shift();                                //remove the scheduled time from the tutors availability in the temp cTutors array
        console.log(tutor.availability[day.dayOfWeek].values)
        console.log(tutor.tutorName + " " + day.dayOfWeek + " " + cl.cName)
        //console.log(Tutors.indexOf((Tutors.filter(temp=>{return tutor.tutorName === temp.tutorName}))[0]))
        console.log("Removing: " + Tutors[Tutors.indexOf((Tutors.filter(temp=>{return tutor.tutorName === temp.tutorName}))[0])].availability[day.dayOfWeek].values[0])
        Tutors[Tutors.indexOf((Tutors.filter(temp=>{return tutor.tutorName === temp.tutorName}))[0])].availability[day.dayOfWeek].values.shift();        //remove the scheduled time for the tutors availability in the final Tutors array
        return (tutor.availability[day.dayOfWeek].values.length <= 0);                  //return true if tutor has no more availability for the day, false otherwise
    } else {
        tutor.availability[day.dayOfWeek].values.shift();                                //remove the unscheduled timeblock from the array as it will never be able to be scheduled for this class
        return (tutor.availability[day.dayOfWeek].values.length <= 0) ? true : scheduleTimeBlock(day,cl,tutor,Tutors);  //recurse to the next available time for the tutor and attempt to schedule, return true if no more availability
    }
}