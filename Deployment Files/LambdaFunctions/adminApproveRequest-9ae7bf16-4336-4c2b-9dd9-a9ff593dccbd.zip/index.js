//construct aws objects
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();
const lambda = new AWS.Lambda();

//lambda handler
//callsback true if request is entered to the database and the user is notified false otherwise
exports.handler = async (event,context,callback) => {
    await updateRequest(event.requestID).then(result=>callNotifyUser(event.userID,event.comments)).then(result=>{callback(null,true)}).catch(error=>callback(false));
};

//notifies the user of the request about the status of their request
function callNotifyUser(userId,comments) {
    console.log("notify");
    var notifyPayload = {
        "userId" : userId,
        "requestStatus" : 1,
        "comments" : comments
    };
    var params = {
        FunctionName : process.env.notifyUserFunc,
        InvocationType : "RequestResponse",
        Payload : JSON.stringify(notifyPayload),
    };
    return new Promise((resolve,reject)=> {
        lambda.invoke(params,(err,data) => {
        if (err) {
           console.error(err);
           reject(err);
        }
            console.log("Notify User success");
            resolve(data.Payload);
        });
    });
}

function updateRequest(requestID) {
    var options = {
      TableName: process.env.RequestsTable,
      Key: {
        'requestID' : requestID
      },
      UpdateExpression: 'set #status = :s',
      ExpressionAttributeNames: {
        "#status" : "status"  
      },
      ExpressionAttributeValues: {
        ':s' : 1,
      }
    };
    return new Promise(function(resolve,reject) {
        //put the item to the db
        dynamo.update(options, function (err, data) {
            if (err) {
                console.error(err);
                reject(err);
            }
            resolve(data);
        });
    });
}