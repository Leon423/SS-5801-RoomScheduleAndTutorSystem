//construct aws objects
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

/*
* lambda handler
* callsback an array of pending requests on success
*/
exports.handler = async (event,context,callback) => {
    var response = await cancelRequest(event.requestID).then(function(result) {
      return(result);
    }, function(err) {
      callback(err);
    });
    callback(null,response);
};

/*
* Scans the DB requests table for pending requests
*/
function cancelRequest(requestID) {
  var options = {
      TableName : process.env.RequestsTable,
      Key : {
          "requestID" : requestID
      },
  };
  return new Promise(function(resolve,reject) {
    dynamo.delete(options, function(err,data){
      if (err) {
        reject(false);
      } else {
        console.log("Scan results" + data);
        resolve(true);
      }
    });
  });
}