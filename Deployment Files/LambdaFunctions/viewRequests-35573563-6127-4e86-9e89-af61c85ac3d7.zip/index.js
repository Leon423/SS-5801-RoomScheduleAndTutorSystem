//construct aws objects
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();

/*
* lambda handler
* callsback an array of pending requests on success
*/
exports.handler = async (event,context,callback) => {
    var requests = await getRequests(event.userID).then(function(result) {
      return(result);
    }, function(err) {
      callback(err);
    });
    callback(null,requests);
};

/*
* Scans the DB requests table for pending requests
*/
function getRequests(userID) {
  var options = {
      TableName : process.env.RequestsTable,
      FilterExpression : "#userReservedID = :userID",
      ExpressionAttributeNames: {
          "#userReservedID" : 'userReservedID'
      },
      ExpressionAttributeValues: {
          ":userID" : userID
      }
  };
  return new Promise(function(resolve,reject) {
    dynamo.scan(options, function(err,data){
      if (err) {
        reject(err);
      } else {
        console.log("Scan results" + data);
        resolve(data.Items);
      }
    });
  });
}