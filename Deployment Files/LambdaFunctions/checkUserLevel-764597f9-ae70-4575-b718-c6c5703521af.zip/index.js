const AWS = require('aws-sdk');
var cognito = new AWS.CognitoIdentityServiceProvider({region: 'us-east-2'});

exports.handler = async (event, context, callback) => {
    var userLevel = await getUserLevel(event.userID);
    switch(event.typeCheck) {
        case 'user':
            return (userLevel == 0 || userLevel == 1);
        case 'admin':
            return (userLevel == 2)
    }
};

function listUsers(params) {
    return new Promise((resolve,reject)=>{
       cognito.listUsers(params,(err,data)=>{
    	    if(err){
        		reject(err);
        	} else {
        		resolve(data.Users);
        	}
        }); 
    });
}

//gets the user's email by calling list user with filter params to find the user by username
async function getUserLevel(userId) {
    var params = {
	    UserPoolId: 'us-east-2_0HlnZbskF',
    };
    return await listUsers(params).then(result=>{
            return result.filter(user=>{
                return user.Username === userId;
            })[0].Attributes.filter(atr=>{
                return atr.Name === "custom:userLevel";
            })[0].Value;
        },error=>console.log(error));
}