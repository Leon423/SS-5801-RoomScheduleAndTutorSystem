//construct aws objects
const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient();
const uuid = require('uuid/v1');
const lambda = new AWS.Lambda();

//lambda handler
//callsback true if request is entered to the database and the user is notified false otherwise
exports.handler = async (event,context,callback) => {
    if (await checkForOverlap(event.dateReserved,event.timeBlockReservedID,event.roomReservedID,event.comments)) {;
        var response = await submitToRequestsTable(event.dateReserved,event.comments,event.timeBlockReservedID,event.roomReservedID,event.reoccuring)
            .then(result=>{return true},error=>{return false})
            .catch(error=>{return false});
        callback(null,response);
    } else callback(null,false);
};

//submits the request data to the database
function submitToRequestsTable(date,desc,timeBlockReservedID,roomReservedID,reoccuring) {
	var options = {
      TableName: process.env.RequestsTable,
      Item: {
      	"requestID" : uuid(),
      	"dateReserved" : date,
      	"descriptionOfEvent" : desc,
      	"reoccuring" : reoccuring,
      	"timeBlockReservedID" : {
      	    'wrapperName': 'Set', 
      	    'values': timeBlockReservedID, 
      	    'type': 'Number' },
      	"roomReservedID" : roomReservedID,
      	"status" : 1,
      	"userReservedID" : "ADMIN_REQUEST",
      	"subjectOfEvent" : "Request",
      	"reasonForDenial" : "N/A"
      }
    };
    return new Promise(function(resolve,reject) {
        dynamo.put(options, function (err, data) {
            if (err) {
                reject(err);
            }
            resolve(data);
        });
    });
}

//notifies the user of the request about the status of their request
function callNotifyUser(userId,comments) {
    console.log("notify");
    var notifyPayload = {
        "userId" : userId,
        "requestStatus" : -2,
        "comments" : comments
    };
    var params = {
        FunctionName : process.env.notifyUserFunc,
        InvocationType : "RequestResponse",
        Payload : JSON.stringify(notifyPayload),
    };
    return new Promise((resolve,reject)=> {
        lambda.invoke(params,(err,data) => {
        if (err) {
           //console.log(err);
           reject(err);
        }
            //console.log(data.Payload);
            resolve(data.Payload);
        });
    });
}

async function checkForOverlap(selectedDate,timeBlockArr,roomID,comments) {
    var reservations = await getReservations(selectedDate);
    //console.log(reservations)
    reservations.forEach(async (res)=>{
        console.log("comments: " + comments)
        for(let i=0;i<res.timeBlockReservedID.values.length;i++) {
           if (timeBlockArr.indexOf(res.timeBlockReservedID.values[i]) != -1) {
               if (!await resolveConflict(res,comments).then(result=>{return result},error=>{return error})) {
                   return false;
               }
               break;
           } 
        }
    });
    return true;
}

//scan database for reservations
function getReservations(selectedDate) {
  //var selectedDateAsDate = new Date(selectedDate);
  var DOW = (new Date(selectedDate)).getDay();
  console.log('Day of week:' + DOW);
  return new Promise(function(resolve,reject) {
    var options = {
      TableName : process.env.RequestsTable,
      FilterExpression: "(#dateReserved = :dateReservedValue) OR (#reoccuring = :reoccuring)",
      ExpressionAttributeNames: {
        "#dateReserved" : "dateReserved",
        "#reoccuring" : "reoccuring"
      },
      ExpressionAttributeValues: {
        ":dateReservedValue" : selectedDate,
        ":reoccuring" : DOW
      }
    };
    //console.log(options);
    dynamo.scan(options, function(err,data){
      if (err) {
        reject(err);
      } else {
        console.log(data.Items);
        resolve(data.Items);
      }
    });
  });
}

function resolveConflict(res,comments) {
    return new Promise((resolve,reject)=>{
        //console.log(res.requestID + " " + comments)
        cancelReservation(res.requestID)
            .then(result=>{callNotifyUser(res.userReservedID,comments)},error=>{reject(false)})
            .then(result=>{resolve(true)},error=>{reject(false)});
    });
}

function cancelReservation(requestID) {
    var options = {
      TableName: process.env.RequestsTable,
      Key: {
        'requestID' : requestID
      },
      UpdateExpression: 'set #status = :s',
      ExpressionAttributeNames: {
        "#status" : "status"  
      },
      ExpressionAttributeValues: {
        ':s' : -2,
      }
    };
    return new Promise(function(resolve,reject) {
        //put the item to the db
        dynamo.update(options, function (err, data) {
            if (err) {
                console.error(err);
                reject(err);
            }
            resolve(data);
        });
    });
}